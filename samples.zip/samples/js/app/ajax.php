<?php
sleep(2);
print('こんにちは、'.$_REQUEST['name'].'さん！');
?>