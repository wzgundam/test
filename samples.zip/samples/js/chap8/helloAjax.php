<?php
sleep(3);
print('こんにちは、'.$_REQUEST['name'].'さん！');
