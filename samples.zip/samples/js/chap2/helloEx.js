	// document.writelnは、指定された文字列を表示するための命令です。
document.writeln('Hello, World！');