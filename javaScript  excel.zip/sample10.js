var fso = new ActiveXObject("Scripting.FileSystemObject");

var excel = new ActiveXObject("Excel.Application");
excel.DisplayAlerts = false;

try {

	
    var workbook = excel.Workbooks.Open("C:\\Users\\kwon\\Desktop\\aa\\sample12.xlsm", 0, true);
    
    try {
    	excel.Run( "sample12.xlsm!Module1.macro1");
    	
        var worksheet = workbook.Worksheets(1);
        
        document.writeln(worksheet.Cells(7, 1).value);
        
    } finally {
        workbook.Close();
    }
} finally {
	excel.DisplayAlerts = true;
    excel.Quit();
}