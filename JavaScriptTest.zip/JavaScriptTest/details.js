var txtAmount;
var txtMemo;
var selectGoods;


function initDetails() {
	//�����ݒ������֐�
	txtAmount = document.getElementById("txtAmount");
	txtMemo = document.getElementById("txtMemo");

	txtAmount.onfocus = function (){focus(this);}
	txtAmount.onblur = function (){blur(this);}
	txtMemo.onfocus = function (){focus(this);}
	txtMemo.onblur = function (){blur(this);}

	document.getElementById("btnInsertDetails").onclick = function (){dataInsertDetails();}
	document.getElementById("btnUpdateDetails").onclick = function (){dataUpdateDetails();}
	document.getElementById("btnDeleteDetails").onclick = function (){dataDeleteDetails();}
	document.getElementById("linkNewDetails").onclick = function (){return newDetails();}

	dbConnect();
	slipDisplay();
	goodsDisplay();
}


function detailsDisplay() {
	//���ׂ�\������֐�
	var mySql = "select DETAILS_CD,GOODS_NAME,PRICE,AMOUNT,(PRICE * AMOUNT),MEMO ";
	mySql = mySql + "from T08Details,T06Goods ";
	mySql = mySql + "where T08Details.GOODS_CD = T06Goods.GOODS_CD ";
	mySql = mySql + "and SLIP_CD = " + txtSlipCd.value;
	mySql = mySql + " order by DETAILS_CD";
	var recordSet = database.Execute(mySql);

	document.getElementById("detailsDisplay").innerHTML = "";

	var tempHtml = "<select size=\"10\" name=\"selectDetails\" id=\"selectDetails\">\n";
	while (!recordSet.EOF){
		tempHtml = tempHtml + "\t<option value=\"" + recordSet(0) + "\">";
		tempHtml = tempHtml + " [GOODS_NAME]:" + recordSet(1) + " [PRICE]:" + recordSet(2);
		tempHtml = tempHtml + " [AMOUNT]:" + recordSet(3) + " [P*A]:" + recordSet(4);
		tempHtml = tempHtml + " [MEMO]:" + recordSet(5);
		tempHtml = tempHtml + "</option>\n";
		recordSet.MoveNext();
	}
	tempHtml = tempHtml + "</select>";

	//alert(tempHtml);
	document.getElementById("detailsDisplay").innerHTML = tempHtml;
	document.getElementById("selectDetails").onchange = function (){detailsChange(this);}

	recordSet.Close();
	recordSet = null;

	totalDisplay();
}


function detailsChange(obj) {
	//���ׂ�I���������̊֐�
	var mySql = "select GOODS_CD,AMOUNT,MEMO ";
	mySql = mySql +"from T08Details ";
	mySql = mySql +"where Details_CD = " + obj.value ;
	var recordSet = database.Execute(mySql);

	selectGoods.selectedIndex = goodsIndexSearch(recordSet(0));
	txtAmount.value = recordSet(1);
	txtMemo.value = recordSet(2);

	recordSet.Close();
	recordSet = null;

	sqlDisplay("selectedIndex:" + obj.selectedIndex + "�@value:" + obj.value);
}


function goodsDisplay() {
	//���i��\������֐�

	var mySql = "select GOODS_CD,GOODS_NAME from T06Goods order by GOODS_CD";
	var recordSet = database.Execute(mySql);

	document.getElementById("goodsDisplay").innerHTML = "";

	var tempHtml = "<select name=\"selectGoods\" id=\"selectGoods\">\n";
	tempHtml = tempHtml + "\t<option value=\"0\">�I�����Ă��������B</option>\n";
	while (!recordSet.EOF){
		tempHtml = tempHtml + "\t<option value=\"" + recordSet(0) + "\">" + recordSet(1) + "</option>\n";
		recordSet.MoveNext();
	}
	tempHtml = tempHtml + "</select>";

	//alert(tempHtml);
	document.getElementById("goodsDisplay").innerHTML = tempHtml;
	selectGoods = document.getElementById("selectGoods");
	selectGoods.onchange = function (){goodsChange(this);}

	recordSet.Close();
	recordSet = null;
}


function goodsChange(obj) {
	//���i��I���������̊֐�

	if(obj.selectedIndex==0){
		document.getElementById("sqlDisplay").innerHTML = "";
		alert("���i��I�����Ă��������B");
	}else{
		sqlDisplay("selectedIndex:" + obj.selectedIndex + "�@value:" + obj.value);
	}

}


function sqlDisplay(_mySql) {
	//SQL��\������֐�
	document.getElementById("sqlDisplay").innerHTML = "<p>" + _mySql + "</p>";
}


function newDetails(){
	//���ׂ�V�K�쐬����֐�
	textClearDetails();
	document.getElementById("sqlDisplay").innerHTML = "";
	goodsDisplay();
	detailsDisplay();
	selectGoods.focus();
	return false;
}


function textClearDetails() {
	//�e�L�X�g�{�b�N�X���N���A����֐�
	txtAmount.value = "";
	txtMemo.value = "";
}


function dataInsertDetails() {
	//�f�[�^��ǉ�����֐�

	try{
		if(dataCheckDetails(1)){
			var mySql = "insert into T08Details(SLIP_CD,GOODS_CD,AMOUNT,MEMO) ";
			mySql = mySql + "values(";
			mySql = mySql + Number(txtSlipCd.value) + ",";
			mySql = mySql + Number(selectGoods.value) + ",";
			mySql = mySql + Number(txtAmount.value) + ", '";
			mySql = mySql + txtMemo.value + "'";
			mySql = mySql +")";

			sqlDisplay(mySql);
			database.Execute(mySql);
			textClearDetails();
			goodsDisplay();
			detailsDisplay();
			alert("�ǉ����܂����B");

		}
	}catch(error){
		alert(error.number + "\n" + error.description);
	}
}


function dataUpdateDetails() {
	//�f�[�^���X�V����֐�
	if(selectDetails.value==""){
		alert("���ׂ��I������Ă��܂���B");
		return ;
	}
	if(!confirm("�{���ɍX�V���܂����H")){
		return ;
	}
	if(dataCheckDetails(1)){
		var mySql = "update T08Details set ";
		mySql = mySql + "GOODS_CD = " + Number(selectGoods.value);
		mySql = mySql + ",AMOUNT = " + Number(txtAmount.value);
		mySql = mySql + ",MEMO = '" + txtMemo.value + "'";
		mySql = mySql + " where Details_CD = " + Number(selectDetails.value);
		sqlDisplay(mySql);
		database.Execute(mySql);
		textClearDetails();
		goodsDisplay();
		detailsDisplay();
		alert("�X�V���܂����B");
	}
}


function dataDeleteDetails() {
	//�f�[�^���폜����֐�
	if(selectDetails.value==""){
		alert("���ׂ��I������Ă��܂���B");
		return ;
	}
	if(!confirm("�{���ɍ폜���܂����H")){
		return ;
	}
	if(dataCheckDetails(0)){
		var mySql = "delete from T08Details where Details_CD = " + Number(selectDetails.value);
		sqlDisplay(mySql);
		database.Execute(mySql);
		textClearDetails();
		goodsDisplay();
		detailsDisplay();
		alert("�폜���܂����B");
	}
}


function dataCheckDetails(flag){
	//�f�[�^���`�F�b�N����֐�
	var tempStr = "�͕K�����͂��Ă��������B";

	if (flag == 1 && selectGoods.value == 0) {
		alert("GOODS_CD" + "�͕K���I�����Ă��������B");
		return false;
	}
	if (flag == 1 && txtAmount.value == "") {
		alert("AMOUNT" + tempStr);
		return false;
	}
	if (flag == 1 && txtAmount.value.match(/[^0-9]/)) {
		alert("AMOUNT�ɂ͔��p��������͂��Ă��������I");
		txtAmount.focus();
		return false;
	}
	if (flag == 1 && txtMemo.value == "") {
		alert("Memo" + tempStr);
		return false;
	}

	return true;
}


function goodsIndexSearch(goodsCd){
	//���i�I���{�b�N�X��Index����������֐�
	var mySql = "select count(GOODS_CD) from (select GOODS_CD from T06Goods where GOODS_CD <= " + goodsCd + " order by GOODS_CD)";
	var recordSet = database.Execute(mySql);
	var goodsIndex = recordSet(0);
	return goodsIndex;
}


function totalDisplay(){
	//���ׂ�total���v�Z����֐�
	var mySql = "select sum(PRICE * AMOUNT) ";
	mySql += "from T08Details,T06Goods ";
	mySql += "where T08Details.GOODS_CD = T06Goods.GOODS_CD ";
	mySql += "and SLIP_CD = " + txtSlipCd.value;
	var recordSet = database.Execute(mySql);
	var tempHtml = "TOTAL:" + recordSet(0) + "�~";
	document.getElementById("totalDisplay").innerHTML = tempHtml;

	recordSet.Close();
	recordSet = null;
}
