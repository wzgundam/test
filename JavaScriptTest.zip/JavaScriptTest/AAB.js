var database;

onload = init;
onunload = dbClose;

function init() {
 	
 	var file_path = location.pathname;
 	var db_path_name;
 	var db_path = file_path.split("/").reverse().slice(1).reverse().join("\\");
 	
 	db_path_name = db_path.toString().substring(1,db_path.length);
 	
 	
 	document.writeln(db_path);
 	document.writeln(db_path.length);
 	document.writeln(db_path_name + "\\SampleDB010.mdb;");
 	

	
//	document.writeln(aa);
//	document.writeln(data[0]);
//	document.writeln(data[0]);
//  dbConnect(db_path_name + "\\SampleDB010.mdb;");
  dbConnect();
}

//�f�[�^�x�[�X�ɐڑ�
function dbConnect() {
  alert();	
  database = new ActiveXObject("ADODB.Connection");
  alert("bb");
//  database.Open("Driver={Microsoft Access Driver (*.mdb)}; DBQ=" + db_path );
  database.Open("Driver={Microsoft Access Driver (*.mdb)}; DBQ= C:\\Users\\EF151\\Desktop\\SampleDB010\\SampleDB010.mdb;");
  alert("aaa");
}

//�f�[�^�x�[�X��ؒf
function dbClose() {
  database.Close();
  database = null;
  alert("�f�[�^�x�[�X��ؒf���܂����B");
}