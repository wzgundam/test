
var database;

onload = init;
onunload = dbClose;

function init() {

 	var file_path = location.pathname;
 	var db_path_name;
 	var db_path = file_path.split("/").reverse().slice(1).reverse().join("\\");
 	
 	db_path_name = db_path.toString().substring(1,db_path.length);
 	 	
  dbConnect(db_path_name + "\\DB.mdb;");
  dataDisp();
}

//�f�[�^�x�[�X�ɐڑ�
function dbConnect(db_path_name) {
  alert("111");	
  database = new ActiveXObject("ADODB.Connection");
  database.Open("Driver={Microsoft Access Driver (*.mdb)}; DBQ= " + db_path_name );
  alert("�f�[�^�x�[�X�ɐڑ����܂����B");
}

//�f�[�^�x�[�X��ؒf
function dbClose() {
  database.Close();
  database = null;
  alert("�f�[�^�x�[�X��ؒf���܂����B");
}

function focus(obj){
  obj.style.backgroundColor = "#ffff00";
}

function blur(obj){
  obj.style.backgroundColor = "#ffffff";
}

//�f�[�^�\��
function dataDisp() {

	alert("333");	
    var mySql = "select * from aa ";
    var recordSet = database.Execute(mySql);
	
	alert("444");	
	
    var tempHtml="";
    document.getElementById("disp").innerHTML = "";
    while (!recordSet.EOF){
      tempHtml = tempHtml + recordSet(0) + ":" + recordSet(1) + "<br />";
      recordSet.MoveNext();
    }
    document.getElementById("disp").innerHTML = tempHtml;
    recordSet.Close();
    recordSet = null;
/**/
}