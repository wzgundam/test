package util;

public class HtmlRule {
    
    static final String BREAK = "<br/>";
    static final char LF = '\n';
    static final char LR = '\r';
    static final char LO = '-';
    static final char LS = '/';
    
    /**
     * å�󼼳����� å�Ұ��� å����� ǥ���ϱ� ����  \n�� <br/>�� ġȯ�Ѵ�.
     * 
     * @param text String
     * @return
     */
    public String getText(String text){
        
        int text_len = text.length();
        if(text_len == 0){
            return "";
        }
        StringBuffer textbuffer = new StringBuffer();
        
        for(int i=0; i<text_len; i++){
            char ch = text.charAt(i);
            switch(ch){
            case LF:
                textbuffer.append(BREAK);
                break;
            default:
                textbuffer.append(ch);
                break;
            }
            
        }
        return textbuffer.toString();
    }
    
    public String setText(String text){
        
        int text_len = text.length();
        if(text_len == 0){
            return "";
        }
        StringBuffer textbuffer = new StringBuffer();
        
        for(int i=0; i<text_len; i++){
            char ch = text.charAt(i);
            switch(ch){
            case LR:
            	textbuffer.append(ch);
                textbuffer.append(LF);
                i = i+5;
                break;
            default:
                textbuffer.append(ch);
                break;
            }
            
        }
        return textbuffer.toString();
    }
    
    public String setDate(String text){
        
        int text_len = text.length();
        if(text_len == 0){
            return "";
        }
        StringBuffer textbuffer = new StringBuffer();
        
        for(int i=0; i<text_len; i++){
            char ch = text.charAt(i);
            switch(ch){
            case LO:
            	textbuffer.append(LS);
                break;
            default:
                textbuffer.append(ch);
                break;
            }
            
        }
        return textbuffer.toString();
    }
}
