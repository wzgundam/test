package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.MenuForm;

public class MenuAction extends Action{
	public ActionForward execute(
		       ActionMapping mapping,
		       ActionForm form,
		       HttpServletRequest req,
		       HttpServletResponse res)
		       throws Exception{

			MenuForm actionForm=(MenuForm)form;

			String selectMode = "";

			if (actionForm != null) {
				selectMode = actionForm.getSelectMode();
			}

			if (selectMode == null) {
				return mapping.findForward("success");
			} else if (selectMode.equals("管理画面")) {
				return mapping.findForward("manage");
			} else if (selectMode.equals("社員情報修正")) {
				return mapping.findForward("userUpdate");
			} else if (selectMode.equals("作業時間")) {
				return mapping.findForward("workTime");
			} else if (selectMode.equals("個人全体作業状況")) {
				return mapping.findForward("userWorkTime");
			} else if (selectMode.equals("案件全体作業状況ＣＳＶ出力")) {
				return mapping.findForward("workTimeCSV");
			} else{
				return mapping.findForward("success");
			}

		}
	}