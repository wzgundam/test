package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import config.ApplicationContextSingle;
import control.UsersControl;
import control.dao.UserDAO11;
import control.value.Users;
import form.LoginForm;

public class LoginAction extends Action{
	public ActionForward execute(
		       ActionMapping mapping,
		       ActionForm form,
		       HttpServletRequest req,
		       HttpServletResponse res)
		       throws Exception{

			LoginForm actionForm=(LoginForm)form;

			ApplicationContextSingle.init();
			UsersControl control;
			control = (UsersControl) ApplicationContextSingle.getObjectBean("UsersControl");

			String userId = "";
			String userPassword = "";
			String selectMode = "";
			UserDAO11 userDAO = new UserDAO11();
			boolean userExist = false;

			if (actionForm != null) {
				userId = actionForm.getUserId();
				userPassword = actionForm.getUserPassword();
				selectMode = actionForm.getSelectMode();
			}


//			userExist = userDAO.getUserExist(userId,userPassword);

			Users users = control.getUsersData(userId);
			if (users != null) {
				userExist = true;
			}

			if (selectMode == null) {
				return mapping.findForward("success");
			} else if (selectMode.equals("ログイン")) {
				if (userExist == true) {
					return mapping.findForward("menu");
				} else {
					return mapping.findForward("success");
				}
			} else if (selectMode.equals("社員登録")) {
				return mapping.findForward("userRegist");
			} else{
				return mapping.findForward("success");
			}

		}
	}