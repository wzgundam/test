package control;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Driver;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class MsSqlConnector {
	private static java.sql.Connection con = null;
//	private static String driverName;
//	private static String url = "";
//	private static String databaseName = "";
//	private static String userName = "";
//	private static String password = "";

	private static String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private static String url = "jdbc:sqlserver://EF151-OPT990-1\\SQLEXPRESS";
	private static String databaseName = "WorkTimeManage";
	private static String userName = "edufront";
	private static String password = "1";

	private static String getConnectionUrl() {
		return url + ";databaseName=" + databaseName + ";integratedSecurity=false;user=" + userName + ";password=" + password + ";";
	}

	public static java.sql.Connection getConnection() {

		try {
			if (con == null) {
				Properties prop = new Properties();
//				prop.load(new FileInputStream("/config/jdbc.properties"));
//
//				driverName = prop.getProperty("driver");
//				url = prop.getProperty("host");
//				databaseName =  prop.getProperty("databaseName");
//				userName = prop.getProperty("user");
//				password = prop.getProperty("password");

				Driver d = (Driver) Class.forName(driverName).newInstance();
				con = d.connect(getConnectionUrl(), new Properties());
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return con;
	}

	/*
	 * Display the driver properties, database details
	 */
	public void displayDbProperties() {
		java.sql.ResultSet rs = null;
		try {
			con = this.getConnection();
			if (con != null) {
				String SQL = "SELECT * FROM T学校";
				Statement stmt = con.createStatement();
				rs = stmt.executeQuery(SQL);

				while (rs.next()) {
					System.out.println(rs.getString("学校") + ", " + rs.getString("学校名"));
				}
				rs.close();
				rs = null;
				closeConnection();
			} else {
				System.out.println("Error: No active Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static ResultSet sqlSelect(String sql) {
		java.sql.ResultSet rs = null;
		try {
			if (con != null) {
				Statement stmt = con.createStatement();
				return rs = stmt.executeQuery(sql);
			} else {
				System.out.println("Error: No active Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rs;
	}

	public static void closeConnection() {
		try {
			if (con != null)
				con.close();
			con = null;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws Exception {
		MsSqlConnector myDbTest = new MsSqlConnector();
		myDbTest.displayDbProperties();
	}
}
