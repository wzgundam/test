package control.dao;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import org.hibernate.LockMode;
import org.hibernate.Query;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/**
 * 
 * @author $Author: kwon $
 * @version $Revision: 1.1 $
 */
public abstract class BaseRootDAO extends HibernateDaoSupport{
	
	//-------------------------------------------------------------------------
	// Convenience methods for storing individual objects
	//-------------------------------------------------------------------------

	public void update(Object object) throws DataAccessException{
		getHibernateTemplate().update(object);
	}
	
	public void update(List list) throws DataAccessException{
		for(int i=0; i<list.size(); i++) {
			Object object = list.get(i);
			getHibernateTemplate().update(object);
		}
	}
	
	
	public void save(Object object) throws DataAccessException{
		getHibernateTemplate().save(object);
	}
	
	public void save(List list) throws DataAccessException{
		for(int i=0; i<list.size(); i++) {
			Object object = list.get(i);
			getHibernateTemplate().save(object);
		}
	}
	
	
	public void saveOrUpdate(Object entity) throws DataAccessException{
		getHibernateTemplate().saveOrUpdate(entity);
	}
	
	public void saveOrUpdate(String entityName, Object entity) throws DataAccessException{
		getHibernateTemplate().saveOrUpdate(entityName, entity);
	}
	
	public void saveOrUpdateAll(Collection entities) throws DataAccessException{
		getHibernateTemplate().saveOrUpdateAll(entities);
	}
	
	
	public void delete(Object object) throws DataAccessException{
		getHibernateTemplate().delete(object);
	}
	
	public void delete(List list) throws DataAccessException{
		for(int i=0; i<list.size(); i++) {
			Object object = list.get(i);
			getHibernateTemplate().delete(object);
		}
	}
	
	public void deleteAll(Collection entities) throws DataAccessException{
		getHibernateTemplate().deleteAll(entities);
	}
	
	public int bulkUpdate(final String queryString, final Object[] values) throws DataAccessException {
		return getHibernateTemplate().bulkUpdate(queryString, values);
	}
	
	
	
	//-------------------------------------------------------------------------
	// Convenience methods for loading individual objects
	//-------------------------------------------------------------------------

	public Object get(Class name, Serializable id) {
		return getHibernateTemplate().get(name,id);
	}
	
	public Object get(String entityName, Serializable id) {
		return getHibernateTemplate().get(entityName,id);
	}	
	
	public Object get(final Class entityClass, final Serializable id, final LockMode lockMode) {
		return getHibernateTemplate().get(entityClass, id, lockMode);
	}
	
	public List loadAll(Class entityClass) {
		return getHibernateTemplate().loadAll(entityClass);
	}
	
	//-------------------------------------------------------------------------
	// Convenience finder methods for HQL strings
	//-------------------------------------------------------------------------

	public List find(String queryString) {
		return getHibernateTemplate().find(queryString);
	}
	
	public List find(String queryString, Serializable id) {
		return getHibernateTemplate().find(queryString,id);
	}
	
	public List find(String strQuery, Object object) {
		return getHibernateTemplate().find(strQuery,object);
	}
	
	public List find(String strQuery, Object[] objects) {
		return getHibernateTemplate().find(strQuery,objects);
	}
	
	public List find(String strNamedQuery, Object[] objects, int firstResult, int maxResult) {
		Query query = getHibernateTemplate().getSessionFactory().getCurrentSession().createQuery(strNamedQuery);
		if (objects != null) {
			for (int i = 0; i < objects.length; i++) {
				query.setParameter(i, objects[i]);
			}
		}
		query.setFirstResult(firstResult);
		query.setMaxResults(maxResult);
		return query.list();
	}
	
	public List findAll(Class entityClass) {
		return getHibernateTemplate().loadAll(entityClass);
	}
	
	
	public List findByNamedParam(String queryString, String paramName, Object value) {
		return getHibernateTemplate().findByNamedParam(queryString,paramName,value);
	}
	
	public List findByNamedParam(final String queryString, final String[] paramNames, final Object[] values) {
		return getHibernateTemplate().findByNamedParam(queryString,paramNames,values);
	}
	
	
	public List findNamedQuery(String strNamedQuery, Object[] objects) {
		Query query = getHibernateTemplate().getSessionFactory().getCurrentSession().getNamedQuery(strNamedQuery);
		
		for(int i=0; i<objects.length; i++) {
			query.setParameter(i,objects[i]);
		}
		
		return query.list();
	}
	
	public List findNamedQuery(String strNamedQuery, Object[] objects, int firstResult, int maxResult) {
		Query query = getHibernateTemplate().getSessionFactory().getCurrentSession().getNamedQuery(strNamedQuery);
		
		for(int i=0; i<objects.length; i++) {
			query.setParameter(i,objects[i]);
		}
		
		query.setFirstResult(firstResult);
		query.setMaxResults(maxResult);
		
		return query.list();
	}
}
