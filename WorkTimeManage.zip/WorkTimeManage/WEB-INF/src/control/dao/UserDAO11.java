package control.dao;

import java.sql.ResultSet;

import control.MsSqlConnector;
import org.hibernate.dialect.SQLServer2008Dialect;

public class UserDAO11 {
	private String sql = "";
	private String userId = "";
	private String UserName = "";
	private String UserPassword = "";
	private int DepartmentId;
	private int AuthorityId;

	public boolean getUserExist(String userId, String userPassword) {

		MsSqlConnector.getConnection();

		sql = "SELECT * FROM t_User AS kr WHERE kr.UserId = '" + userId +  "' AND kr.UserPassword = '" + userPassword + "'";

		ResultSet rs = MsSqlConnector.sqlSelect(sql);

		if (rs == null) {
			MsSqlConnector.closeConnection();
			return false;
		} else {
			MsSqlConnector.closeConnection();
			return true;
		}

	}

//	public User getUser(String userId, String userPassword) {
//
//		MsSqlConnector.getConnection();
//
//		sql = "SELECT * FROM t_User AS kr WHERE kr.UserId = '" + userId +  "' AND kr.UserPassword = '" + userPassword + "'";
//
//		ResultSet rs = MsSqlConnector.sqlSelect(sql);
//
//		User user  = new User();
//		while (rs.next()) {
//			user.setUserId(rs.getString("UserId"));
//			user.setUserName(rs.getString("UserName"));
//			user.setUserPassword(rs.getString("UserName"));
//
//
//			System.out.println(rs.getString("学校") + ", " + rs.getString("学校名"));
//
//			user.setUserId(userId)
//		}
//		rs.close();
//
//
//		return
//	}

}
