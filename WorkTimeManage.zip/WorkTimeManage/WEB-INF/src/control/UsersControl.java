package control;

import control.dao.UsersHome;
import control.value.Users;

/**
 *
 * @author $Author: kwon $
 * @version $Revision: 1.2 $
 */
public class UsersControl {

	private UsersHome usersDAO;

	public UsersHome getUsersDAO() {
		return usersDAO;
	}

	public void setUsersDAO(UsersHome usersDAO) {
		this.usersDAO = usersDAO;
	}

	public Users getUsersData(String UserId) {
		return usersDAO.findById(UserId);
	}

}
