package form;

import org.apache.struts.action.ActionForm;

public class LoginForm extends ActionForm {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String userId;
	private String userPassword;
	private String selectMode;

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getSelectMode() {
		return selectMode;
	}
	public void setSelectMode(String selectMode) {
		this.selectMode = selectMode;
	}


}
