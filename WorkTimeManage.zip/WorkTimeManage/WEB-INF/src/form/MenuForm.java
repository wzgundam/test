package form;

import org.apache.struts.action.ActionForm;

public class MenuForm extends ActionForm {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String selectMode;

	public String getSelectMode() {
		return selectMode;
	}
	public void setSelectMode(String selectMode) {
		this.selectMode = selectMode;
	}


}
