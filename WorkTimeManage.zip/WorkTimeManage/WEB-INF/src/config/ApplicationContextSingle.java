package config;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ApplicationContextSingle {
	
	private static final String DEFAULT_CONFIG_PATH = "config/applicationContext-hibernate.xml";

	private static ClassPathXmlApplicationContext applicationContext = null;
	
	public static synchronized void init() throws Exception {
		if (applicationContext == null) {
//			applicationContext = new ClassPathXmlApplicationContext(new String[]{DEFAULT_CONFIG_PATH}, false);
			applicationContext = new ClassPathXmlApplicationContext(DEFAULT_CONFIG_PATH);
			applicationContext.refresh();
		}
	}
	
	public static Object getObjectBean(String beanName){
		return applicationContext.getBean(beanName);
	}
}
